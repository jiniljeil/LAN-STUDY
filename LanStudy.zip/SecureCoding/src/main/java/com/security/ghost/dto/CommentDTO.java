package com.security.ghost.dto;

public class CommentDTO {
	private int id ; 
	
	private int user_id ;
	private int board_id ; 
	private int type ; 
	private String content ;
	private String userName;
	private String time;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getBoard_id() {
		return board_id;
	}
	public void setBoard_id(int board_id) {
		this.board_id = board_id;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = new String(content);
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = new String(userName);
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = new String(time);
	} 
	
}
