package com.security.ghost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureCodingApplicationTests {

	@Test
	void contextLoads() {
	}

}
